# SASUKE MODS — Blood Strike (UI demonstrativa)

Projeto Android Studio em Java, com alvo Android 14 (API 34+) e SDK de compilação 35.

## O que contém
- Botão flutuante móvel para abrir/fechar o menu.
- Tema escuro preto/vermelho inspirado no Sharingan.
- Botões AIM e ESP apenas demonstrativos.
- Slider de FOV visual (não controla a câmera do jogo).
- Tela para pedir permissão de sobreposição.

## Limites
Este projeto não lê nem modifica a memória do Blood Strike, não usa os offsets para interagir com partidas e não automatiza mira nem revela jogadores. AIM/ESP e FOV só mudam os rótulos/valores da interface.

## Como gerar o APK
1. Abra a pasta `SASUKE_MODS_BloodStrike` no Android Studio.
2. Aguarde a sincronização do Gradle e instale o Android SDK 35 se solicitado.
3. Use **Build > Build APK(s)**.
4. O APK de teste costuma aparecer em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações
- O projeto-fonte não é um APK compilado. Este ambiente não tem Android SDK/Gradle configurados para compilar e validar o APK aqui.
- O JSON de offsets original foi incluído apenas como referência para análise.

## Compilar sem computador (nuvem)
O ZIP inclui `.github/workflows/android.yml` para compilação na nuvem via GitHub Actions.
1. Crie um repositório no GitHub pelo navegador do celular.
2. Envie os arquivos e pastas deste projeto para o repositório (incluindo `.github/workflows/android.yml`).
3. Abra a aba **Actions** e execute **Build Android APK** (ou aguarde o build após enviar para `main`).
4. Quando terminar, abra a execução concluída e baixe o artifact `SASUKE-MODS-debug-apk`. Extraia o ZIP do artifact para encontrar `app-debug.apk`.
Isso exige conta no GitHub e upload do projeto. O build pode falhar se houver problemas de configuração ou dependências.
