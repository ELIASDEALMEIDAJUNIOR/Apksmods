package com.sasukemods.bloodstrike;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class FloatingService extends Service {
    private WindowManager wm;
    private View bubble, panel;
    private final int red = Color.rgb(220, 20, 60);
    private boolean panelVisible = false;
    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        createBubble();
    }
    private WindowManager.LayoutParams params(int w, int h, int gravity) {
        int type = android.os.Build.VERSION.SDK_INT >= 26 ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(w, h, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT, gravity);
    }
    private TextView label(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setPadding(12, 8, 12, 8); return t;
    }
    private void createBubble() {
        TextView b = label("写", 20);
        b.setText("眼"); b.setGravity(Gravity.CENTER); b.setBackgroundColor(red);
        bubble = b;
        WindowManager.LayoutParams p = params(58, 58, Gravity.TOP | Gravity.LEFT);
        p.x = 18; p.y = 220;
        b.setOnClickListener(v -> togglePanel());
        b.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float tx, ty; boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx=p.x; sy=p.y; tx=e.getRawX(); ty=e.getRawY(); moved=false; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int dx=(int)(e.getRawX()-tx), dy=(int)(e.getRawY()-ty);
                    if (Math.abs(dx)>5 || Math.abs(dy)>5) moved=true;
                    p.x=sx+dx; p.y=sy+dy; wm.updateViewLayout(bubble,p); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    if (!moved) togglePanel(); return true;
                }
                return true;
            }
        });
        wm.addView(bubble, p);
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red)); return b;
    }
    private void togglePanel() {
        if (panelVisible) { removePanel(); return; }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(14, 12, 14, 12);
        box.setBackgroundColor(Color.rgb(18,18,23));
        TextView title = label("◉ SASUKE MODS", 20); title.setTextColor(red); box.addView(title);
        TextView note = label("CONTROLES VISUAIS • DEMO", 11); box.addView(note);
        Button aim = button("AIM  •  VISUAL OFF");
        aim.setOnClickListener(v -> aim.setText(aim.getText().toString().endsWith("OFF") ? "AIM  •  VISUAL ON" : "AIM  •  VISUAL OFF"));
        box.addView(aim);
        Button esp = button("ESP  •  VISUAL OFF");
        esp.setOnClickListener(v -> esp.setText(esp.getText().toString().endsWith("OFF") ? "ESP  •  VISUAL ON" : "ESP  •  VISUAL OFF"));
        box.addView(esp);
        TextView fov = label("FOV VISUAL: 90", 14); box.addView(fov);
        SeekBar seek = new SeekBar(this); seek.setMax(150); seek.setProgress(90);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(red));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(red));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int n, boolean u) { fov.setText("FOV VISUAL: " + n); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        box.addView(seek);
        Button close = button("FECHAR MENU"); close.setOnClickListener(v -> removePanel()); box.addView(close);
        panel = box;
        WindowManager.LayoutParams p = params(280, -2, Gravity.TOP | Gravity.LEFT);
        p.x = 84; p.y = 220;
        wm.addView(panel, p); panelVisible = true;
    }
    private void removePanel() {
        if (panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} panel = null; }
        panelVisible = false;
    }
    @Override public void onDestroy() {
        removePanel();
        if (bubble != null) { try { wm.removeView(bubble); } catch (Exception ignored) {} bubble = null; }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
