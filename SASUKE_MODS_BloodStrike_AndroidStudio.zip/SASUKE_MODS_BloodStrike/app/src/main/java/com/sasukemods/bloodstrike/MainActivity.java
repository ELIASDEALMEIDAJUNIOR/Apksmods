package com.sasukemods.bloodstrike;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int red = Color.rgb(220, 20, 60);
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(12, 12, 16));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 48, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(12, 12, 16));
        TextView title = new TextView(this);
        title.setText("◉ SASUKE MODS");
        title.setTextColor(red); title.setTextSize(28); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = new TextView(this);
        sub.setText("BLOOD STRIKE  •  VISUAL UI DEMO");
        sub.setTextColor(Color.LTGRAY); sub.setTextSize(12); sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = 10;
        root.addView(sub, sp);
        TextView info = new TextView(this);
        info.setText("\nMenu flutuante demonstrativo. Os controles não alteram a mira,\nnão leem a memória do jogo e não revelam inimigos.\n\nToque abaixo e autorize “Sobrepor a outros apps” para exibir a bolinha.");
        info.setTextColor(Color.WHITE); info.setTextSize(15);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin = 28;
        root.addView(info, ip);
        Button start = button("ATIVAR MENU FLUTUANTE");
        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
                Toast.makeText(this, "Autorize a sobreposição e volte ao app.", Toast.LENGTH_LONG).show();
            } else {
                startService(new Intent(this, FloatingService.class));
                Toast.makeText(this, "Menu flutuante ativado.", Toast.LENGTH_SHORT).show();
            }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.topMargin = 30;
        root.addView(start, bp);
        Button stop = button("PARAR MENU");
        stop.setOnClickListener(v -> stopService(new Intent(this, FloatingService.class)));
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2); stp.topMargin = 12;
        root.addView(stop, stp);
        setContentView(root);
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red));
        return b;
    }
}
